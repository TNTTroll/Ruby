module NewtonHelper
end
